# rp-cr-converter
Convert the data read by card reader to date and UIN. [https://rijn.github.io/rp-cr-converter/](https://rijn.github.io/rp-cr-converter/)

- development

```bash
yarn install
yarn start
```

- build

Customize the homepage in `package.json`, then run

```bash
yarn build
```
